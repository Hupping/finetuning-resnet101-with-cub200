import os
import torch
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import torch.nn as nn
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter
import time
import copy
from torchvision.datasets.folder import default_loader
import torch.nn.init as init
from tqdm import tqdm

# 定义自定义数据集类
class CUB200Dataset(datasets.ImageFolder):
    def __init__(self, root, transform=None, train=True):
        self.root = root
        self.transform = transform
        self.train = train

        # 加载必要的标签文件
        self.images = self._load_images()
        self.labels = self._load_labels()
        self.train_test_split = self._load_split()

        # 筛选出训练集或测试集
        if self.train:
            self.images = [self.images[i] for i in range(len(self.images)) if self.train_test_split[i]]
            self.labels = [self.labels[i] for i in range(len(self.labels)) if self.train_test_split[i]]
        else:
            self.images = [self.images[i] for i in range(len(self.images)) if not self.train_test_split[i]]
            self.labels = [self.labels[i] for i in range(len(self.labels)) if not self.train_test_split[i]]

    def _load_images(self):
        images_path = os.path.join(self.root, 'images.txt')
        with open(images_path) as f:
            images = [line.strip().split() for line in f.readlines()]
        return [img[1] for img in images]

    def _load_labels(self):
        labels_path = os.path.join(self.root, 'image_class_labels.txt')
        with open(labels_path) as f:
            labels = [line.strip().split() for line in f.readlines()]
        return [int(label[1]) - 1 for label in labels]  # 类别ID从0开始

    def _load_split(self):
        split_path = os.path.join(self.root, 'train_test_split.txt')
        with open(split_path) as f:
            split = [line.strip().split() for line in f.readlines()]
        return [int(s[1]) == 1 for s in split]

    def __len__(self):
        return len(self.images)

    def __getitem__(self, index):
        img_path = os.path.join(self.root, 'images', self.images[index])
        label = self.labels[index]
        image = default_loader(img_path)
        if self.transform is not None:
            image = self.transform(image)
        return image, label
        
# 定义数据转换操作
data_transforms = {
    'train': transforms.Compose([
        transforms.RandomResizedCrop(224),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
    'test': transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]),
}

# 定义训练函数
def train_model(model, criterion, optimizer, scheduler, train_loader, test_loader, num_epochs=25, exp_name='experiment'):
    # 初始化 TensorBoard
    writer = SummaryWriter(f'runs/{exp_name}')
    
    since = time.time()

    best_model_wts = copy.deepcopy(model.state_dict())
    best_acc = 0.0

    for epoch in range(num_epochs):
        print('Epoch {}/{}'.format(epoch, num_epochs - 1))
        print('-' * 10)

        # 每个 epoch 都有训练阶段
        model.train()  # 设置模型为训练模式

        running_loss = 0.0
        running_corrects = 0

        # 迭代数据
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        for inputs, labels in tqdm(train_loader, desc=f"Epoch {epoch+1}/{num_epochs}"):
            inputs = inputs.to(device)
            labels = labels.to(device)

            # 初始化梯度
            optimizer.zero_grad()

            # 前向传播
            with torch.set_grad_enabled(True):
                outputs = model(inputs)
                _, preds = torch.max(outputs, 1)
                loss = criterion(outputs, labels)

                # 反向传播和优化
                loss.backward()
                optimizer.step()

            # 统计
            running_loss += loss.item() * inputs.size(0)
            running_corrects += torch.sum(preds == labels.data)

        epoch_loss = running_loss / len(train_loader.dataset)
        epoch_acc = running_corrects.double() / len(train_loader.dataset)

        print('\nTrain Loss: {:.4f} Acc: {:.4f}'.format(epoch_loss, epoch_acc))

        # 将损失和准确率记录到 TensorBoard
        writer.add_scalar('Train loss', epoch_loss, epoch)
        writer.add_scalar('Train accuracy', epoch_acc, epoch)

        # 学习率调度
        scheduler.step()

        # 在测试集上进行评估
        model.eval()  # 设置模型为评估模式
        test_running_loss = 0.0
        test_running_corrects = 0

        with torch.no_grad():
            for inputs, labels in test_loader:
                inputs = inputs.to(device)
                labels = labels.to(device)

                outputs = model(inputs)
                _, preds = torch.max(outputs, 1)
                loss = criterion(outputs, labels)

                test_running_loss += loss.item() * inputs.size(0)
                test_running_corrects += torch.sum(preds == labels.data)

        test_loss = test_running_loss / len(test_loader.dataset)
        test_acc = test_running_corrects.double() / len(test_loader.dataset)

        print('Test Loss: {:.4f} Acc: {:.4f}'.format(test_loss, test_acc))

        # 将测试集上的损失和准确率记录到 TensorBoard
        writer.add_scalar('Test loss', test_loss, epoch)
        writer.add_scalar('Test accuracy', test_acc, epoch)

        # 复制最佳模型
        if test_acc > best_acc:
            best_acc = test_acc
            best_model_wts = copy.deepcopy(model.state_dict())

        print()

    time_elapsed = time.time() - since
    print('Training complete in {:.0f}m {:.0f}s'.format(time_elapsed // 60, time_elapsed % 60))
    print('Best Test Acc: {:4f}'.format(best_acc))

    # 加载最佳模型权重
    model.load_state_dict(best_model_wts)
    
    # 保存最佳模型权重
    torch.save(model.state_dict(), f'best_model_{exp_name}.pth')

    # 关闭 TensorBoard
    writer.close()
    
    return model

