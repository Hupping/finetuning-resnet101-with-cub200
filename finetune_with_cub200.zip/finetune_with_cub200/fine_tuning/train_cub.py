from fun import init, CUB200Dataset, DataLoader,data_transforms, nn, torch, optim, train_model

if __name__ == '__main__':
    # 设置数据目录路径
    data_dir = '../CUB_200_2011'  # 使用相对路径指向上一级目录中的数据集

    # 创建训练集数据加载器
    train_dataset = CUB200Dataset(root=data_dir, transform=data_transforms['train'], train=True)
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True, num_workers=4)

    # 创建测试集数据加载器
    test_dataset = CUB200Dataset(root=data_dir, transform=data_transforms['test'], train=False)
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False, num_workers=4)

    # 定义不同超参数组合
    num_epochs_list = [10, 25]
    lr_list = [1e-3, 1e-4]
    scheduler_step_size = 7
    scheduler_gamma = 0.1

    # 遍历不同超参数组合
    for num_epochs in num_epochs_list:
        for lr in lr_list:
            # 加载预训练的 ResNet-101 模型
            from torchvision import models
            model = models.resnet101(weights='IMAGENET1K_V1')  # 确保使用 ResNet-101

            # 修改输出层为200类
            num_classes = 200
            model.fc = nn.Linear(model.fc.in_features, num_classes)

            # 自定义初始化输出层权重
            init.normal_(model.fc.weight, mean=0, std=0.01)
            if model.fc.bias is not None:
                init.constant_(model.fc.bias, 0)

            # 将模型移动到GPU
            device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
            model = model.to(device)

            # 定义损失函数
            criterion = nn.CrossEntropyLoss()

            # 为新定义的输出层使用较大的学习率
            fc_params = list(model.fc.parameters())
            # 为其余参数使用较小的学习率
            base_params = list(model.parameters())[:-2]

            # 创建优化器
            optimizer = optim.Adam([
                {'params': base_params, 'lr': lr / 10},
                {'params': fc_params, 'lr': lr}
            ])

            # 创建学习率调度器
            scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=scheduler_step_size, gamma=scheduler_gamma)

            # 定义实验名称
            exp_name = f'fine_tuning_epochs_{num_epochs}_lr_{lr}'

            # 调用训练函数
            trained_model = train_model(model, criterion, optimizer, scheduler, train_loader, test_loader, num_epochs=num_epochs, exp_name=exp_name)
